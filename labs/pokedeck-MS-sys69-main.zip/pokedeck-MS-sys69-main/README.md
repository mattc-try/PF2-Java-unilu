# Laboratory Pokedeck

The next generation Pokemon card manager that you will write :-)

```
mvn compile
mvn exec:java -Dexec.mainClass="pcg.Pokedeck"
mvn test
```

## Open-closed and single responsibility principles
The Open-closed principle is one of the key principles of Object-Oriented Programming, which states that a classes, modules, functions, etc... Should be open for extension but closed for modification. This means that programmers should be able to add new features to a class for example without modifying its existing code. This principle is used so programmers can build systems that are easy to maintain, and modify over time.

Similarly, the Single Responsibility Principle states that a class should have only one reason to change. This means each classes, modules, functions, etc... should only have one functionality, one job.


The modifications made in Exercise 3.7 improve the design regarding the Open-Closed Principle and the Single-Responsibility Principle.
The introduction of lambda expressions and the java.util.function library allow us to create a general method for filtering the deck ```filter(Predicate<JSONObject> filter)```.

Creating this method we are follow ing the Open-Closed Principle since we can now add more filters without modifying the ```DeckView``` class source code.
These modifications also follow the Single-Responsability principle, as the class ```DeckView``` now has a single responsibility, that is, to display the deck whatever the filters are.

I don't really see an obvious problem to my code regarding these pricinples but I think there is always a way to make the code cleaner more readable and more maintainable. For example we could separate the tests, as now they are all packed in a single class... I think there is always something that can be done however I think that isn't always better. Following the principles to a further extent may  make the code less practical, usable, performant or even necessary. Separating the tests as I said above would make me waste time, make the code less usable as testing will now require two commands and less performant as testing would take longer to do.


Sources:

"Open-Closed Principle" wikipedia article: https://en.wikipedia.org/wiki/Open%E2%80%93closed_principle
"Single-Responsibility Principle" wikipedia article: https://en.wikipedia.org/wiki/Single-responsibility_principle




## Composite design pattern
The Composite Design Pattern is a structural design pattern that allows objects to be treated as a single object or a collection of objects. The pattern composes objects into tree structures to represent part-whole hierarchies.

The ```DeckView``` class is used with the ```Predicate``` class to filter the cards based on their attributes. The filter method in the ```DeckView``` class takes a ```Predicate<JSONObject>``` as a parameter, which acts as the component of the composite pattern. The ```Predicate<JSONObject>``` object filters the cards based on the specified criteria and returns the filtered cards as a new ```DeckView``` object. The ```FilterFactory``` class also uses the ```Predicate``` class to create filter predicates based on specific card attributes which are "name", "hp" and "subtypes".

The UML diagram is /UML/Composite.jpg
I was kinda lost doing it tried to do something anyway but would be good to have a lecture translating actual code to that format

Source:

"Composite pattern" wikipedia article: https://en.wikipedia.org/wiki/Composite_pattern

## Iterator design pattern
The Iterator design pattern provides a way to access elements of an aggregate object (such as a collection) sequentially without exposing the underlying implementation of the collection. It involves defining an interface for accessing elements, and an implementation of that interface that can traverse the elements of the collection.

In the given code, the Iterator design pattern is implemented in the ```DeckView``` class, which implements the Iterable interface and provides an implementation for the ```iterator()``` method. The ```ViewIterator``` inner class provides the implementation for the Iterator interface, allowing iteration over the cards in the deck.

The UML diagram is /UML/Iterator.jpg

Source: 

"Iterator pattern" https://en.wikipedia.org/wiki/Iterator_pattern

