package pcg;

import java.util.function.*;
import org.json.*;

public class FilterFactory {

  public static Predicate<JSONObject> hp(Predicate<Integer> filter) {
    return card -> filter.test(card.getInt("hp"));
  }

  public static Predicate<JSONObject> name(Predicate<String> filter) {
    return card -> filter.test(card.getString("name"));
  }

  public static Predicate<JSONObject> subtype(Predicate<String> filter) {
    return card -> {
      JSONArray subtypeArray = card.getJSONArray("subtypes");
      for (int i = 0; i < subtypeArray.length(); i++) {
        if (filter.test(subtypeArray.getString(i))) {
          return true;
        }
      }
      return false;
    };
  }

  public static Predicate<JSONObject> not(Predicate<JSONObject> predicate) {
    return card -> !predicate.test(card);
  }

  public static Predicate<JSONObject> and(
      Predicate<JSONObject> pred1, Predicate<JSONObject> pred2) {
    return card -> pred1.test(card) && pred2.test(card);
  }

  public static Predicate<JSONObject> or(Predicate<JSONObject> pred1, Predicate<JSONObject> pred2) {
    return card -> pred1.test(card) || pred2.test(card);
  }
}
