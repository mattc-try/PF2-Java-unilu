package pcg;

import java.nio.file.Files;
import java.nio.file.Paths;
import org.json.*;

public class Pokedeck {
  public static void main(String args[]) {
    // Parsing the content String into a JSON structure
    // String content = new String(Files.readAllBytes(Paths.get("src/main/resources/base1.json")));
    // System.out.println(content);

    // The line under would be for a file not starting with [ which should be a JSON Array instead
    // JSONObject object = new JSONObject(content);
    JSONArray array = readJSON("src/main/resources/base1.json");

    // Read the small file and print the name of the first pokemon card in the deck
    // Parsing the content String into a JSON structure
    JSONArray smallArray = readJSON("src/main/resources/small-base1.json");
    ;
    // Create a Json object for the first card
    JSONObject firstCardObj = smallArray.getJSONObject(0);

    // Get the "name" property and print it
    String name = firstCardObj.getString("name");
    System.out.println("First card is: " + name);

    // DeckView methods to get the cards with less hp then indicated with mask filter
    // DeckView deck = new DeckView(smallArray);
    // System.out.println(deck.filterHPLessThan(90).toStringID());

    // Little taste for the name filter as well
    // System.out.println(deck.filterName(pname -> pname.startsWith("Ala")).toStringID());

    // Little test for the iteration typeshit
    // for (JSONObject card : deck) {
    //   System.out.println(card.getString("name"));
    // }
  }

  public static JSONArray readJSON(String path) {
    try {
      String content = new String(Files.readAllBytes(Paths.get(path)));
      // The line under would be for a file not starting with [ which should be a JSON Array instead
      // JSONObject object = new JSONObject(content);
      return new JSONArray(content);
    } catch (Exception e) {
      e.printStackTrace();
      return new JSONArray();
    }
  }
}
