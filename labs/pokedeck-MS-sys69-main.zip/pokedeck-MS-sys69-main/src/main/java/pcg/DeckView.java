package pcg;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.function.*;
import org.json.*;

// Added the implements for the iteration in exe4
public class DeckView implements Iterable<JSONObject> {
  private JSONArray deck;
  private ArrayList<Integer> view;

  public DeckView(JSONArray deck) {
    this.deck = deck;
    // The view ArrayList matching the size of the deck
    this.view = new ArrayList<Integer>();
    for (int i = 0; i < deck.length(); i++) {
      this.view.add(i);
    }
  }

  // Create the deck with the new view
  public DeckView(JSONArray deck, ArrayList view) {
    this.deck = deck;

    // The view is now given as parameter
    this.view = view;
  }

  public String toStringID() {
    String cardIDs = "";

    // Create the string by getting all cards id in a string separated by commas
    // Changed deck.size() to view as well as the card intake to match E2T6
    // for (int i = 0; i < view.size(); i++) {
    //   JSONObject card = deck.getJSONObject(view.get(i));
    //   String id = card.getString("id");
    //   cardIDs += id + ",";
    // }

    // Same thing as above using the iterator
    for (JSONObject card : this) {
      String id = card.getString("id");
      cardIDs += id + ",";
    }

    // Remove the last comma
    if (cardIDs.length() > 0) {
      cardIDs = cardIDs.substring(0, cardIDs.length() - 1);
    }

    return cardIDs;
  }

  // public DeckView filterHPLessThan(int hp) {
  //   // The ArrayList to return with the new "view"
  //   ArrayList<Integer> filteredView = new ArrayList<Integer>();

  //   for (int i = 0; i < view.size(); i++) {
  //     JSONObject card = deck.getJSONObject(view.get(i));

  //     // Get the "hp" value
  //     int hpCard = card.getInt("hp");

  //     // Compare if the hp is less than the max then add to new ArrayList
  //     if (hpCard < hp) {
  //       filteredView.add(view.get(i));
  //     }
  //   }
  //   return new DeckView(deck, filteredView);
  // }

  // public DeckView filterHP(Predicate<Integer> hpFilter) {
  //   // The ArrayList to return with the new "view"
  //   ArrayList<Integer> filteredView = new ArrayList<Integer>();

  //   for (int i = 0; i < view.size(); i++) {
  //     JSONObject card = deck.getJSONObject(view.get(i));

  //     // Get the "hp" value
  //     int hpCard = card.getInt("hp");

  //     // Check if the hp satisfies the predicate
  //     if (hpFilter.test(hpCard)) {
  //       filteredView.add(view.get(i));
  //     }
  //   }
  //   return new DeckView(deck, filteredView);
  // }

  // public DeckView filterName(Predicate<String> nameFilter) {
  //   // The ArrayList to return with the new "view"
  //   ArrayList<Integer> filteredView = new ArrayList<Integer>();

  //   for (int i = 0; i < view.size(); i++) {
  //     JSONObject card = deck.getJSONObject(view.get(i));

  //     // Get the "name" string
  //     String name = card.getString("name");

  //     // Check if the name is the same as the one in the filter
  //     if (nameFilter.test(name)) {
  //       filteredView.add(view.get(i));
  //     }
  //   }
  //   return new DeckView(deck, filteredView);
  // }

  public DeckView filter(Predicate<JSONObject> filter) {
    // The ArrayList to return with the new "view"
    ArrayList<Integer> filteredView = new ArrayList<Integer>();

    for (int i = 0; i < view.size(); i++) {
      JSONObject card = deck.getJSONObject(view.get(i));

      // Check if the card satisfies the predicate
      if (filter.test(card)) {
        filteredView.add(view.get(i));
      }
    }
    return new DeckView(deck, filteredView);
  }

  // The iiner class
  private class ViewIterator implements Iterator<JSONObject> {
    private int currentIndex = 0;

    // Override hasNext method
    @Override
    public boolean hasNext() {
      return currentIndex < view.size();
    }

    // Override next methood
    @Override
    public JSONObject next() {
      JSONObject card = deck.getJSONObject(view.get(currentIndex));
      currentIndex++;
      return card;
    }
  }

  // Implement Iterable interface
  @Override
  public Iterator<JSONObject> iterator() {
    return new ViewIterator();
  }
}
