package pcg;

import static org.junit.jupiter.api.Assertions.*;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.function.*;
import org.json.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class DeckViewTest {

  private DeckView object;

  @BeforeEach
  void init() throws Exception {

    String smallContent =
        new String(Files.readAllBytes(Paths.get("src/main/resources/small-base1.json")));
    JSONArray smallArray = new JSONArray(smallContent);
    object = new DeckView(smallArray);
  }

  // void populate() {
  //   list.add(4);
  //   list.add(5);
  //   list.add(6);
  // }

  // void testArrayContent(int size, String content) {
  //   assertEquals(content, list.toString());
  //   assertEquals(size, list.size());
  //   assertEquals(size == 0, list.isEmpty());
  // }

  @Test
  @DisplayName("test of the toStringID() method")
  public void testToString() {
    assertEquals("base1-1,base1-2,base1-3,base1-4,base1-5", object.toStringID());
  }

  // @Test
  // @DisplayName("test of the filterHPLessThan() method")
  // public void testFilterHPLessThan() {
  //   DeckView filterViewSmall = object.filterHPLessThan(1);
  //   assertEquals("", filterViewSmall.toStringID());

  //   DeckView filterViewMid = object.filterHPLessThan(90);
  //   assertEquals("base1-1,base1-5", filterViewMid.toStringID());

  //   DeckView filterViewBig = object.filterHPLessThan(200);
  //   assertEquals("base1-1,base1-2,base1-3,base1-4,base1-5", filterViewBig.toStringID());
  // }

  @Test
  @DisplayName("test of the hp filter")
  public void testFilterHP() {
    DeckView filterViewSmaller = object.filter(FilterFactory.hp(hp -> hp < 80));
    assertEquals("base1-5", filterViewSmaller.toStringID());

    Predicate<JSONObject> hpFilterEqual = FilterFactory.hp(hp -> hp == 120);
    DeckView filterViewEqual = object.filter(hpFilterEqual);
    assertEquals("base1-3,base1-4", filterViewEqual.toStringID());

    Predicate<JSONObject> hpFilterNotEqual = FilterFactory.hp(hp -> hp != 120);
    DeckView filterViewNotEqual = object.filter(hpFilterNotEqual);
    assertEquals("base1-1,base1-2,base1-5", filterViewNotEqual.toStringID());

    Predicate<JSONObject> hpFilterBigger = FilterFactory.hp(hp -> hp > 100);
    DeckView filterViewBigger = object.filter(hpFilterBigger);
    assertEquals("base1-3,base1-4", filterViewBigger.toStringID());
  }

  @Test
  @DisplayName("test of the name filter")
  public void testFilterName() {
    Predicate<JSONObject> nameFilterEqualsS = FilterFactory.name(name -> name.equals("Alakazam"));
    DeckView filterViewEqualsS = object.filter(nameFilterEqualsS);
    assertEquals("base1-1", filterViewEqualsS.toStringID());

    Predicate<JSONObject> nameFilterContains = FilterFactory.name(name -> name.contains("fair"));
    DeckView filterViewContains = object.filter(nameFilterContains);
    assertEquals("base1-5", filterViewContains.toStringID());

    Predicate<JSONObject> nameFilterEnd = FilterFactory.name(name -> name.endsWith("toise"));
    DeckView filterViewEnd = object.filter(nameFilterEnd);
    assertEquals("base1-2", filterViewEnd.toStringID());

    Predicate<JSONObject> nameFilterStart = FilterFactory.name(name -> name.startsWith("Chan"));
    DeckView filterViewStart = object.filter(nameFilterStart);
    assertEquals("base1-3", filterViewStart.toStringID());

    Predicate<JSONObject> nameFilterBLength = FilterFactory.name(name -> name.length() > 7);
    DeckView filterViewBLength = object.filter(nameFilterBLength);
    assertEquals("base1-1,base1-2,base1-4,base1-5", filterViewBLength.toStringID());

    Predicate<JSONObject> nameFilterSLength = FilterFactory.name(name -> name.length() <= 7);
    DeckView filterViewSLength = object.filter(nameFilterSLength);
    assertEquals("base1-3", filterViewSLength.toStringID());
  }

  @Test
  @DisplayName("test of the subtype filter")
  public void testFilterSubtype() {
    Predicate<JSONObject> subtypeFilterContainsB =
        FilterFactory.subtype(subtype -> subtype.contains("B"));
    DeckView filterViewContains = object.filter(subtypeFilterContainsB);
    assertEquals("base1-3,base1-5", filterViewContains.toStringID());

    Predicate<JSONObject> subtypeFilterEqualsBasic =
        FilterFactory.subtype(subtype -> subtype.equals("Basic"));
    DeckView filterViewEquals = object.filter(subtypeFilterEqualsBasic);
    assertEquals("base1-3,base1-5", filterViewEquals.toStringID());

    Predicate<JSONObject> subtypeFilterEnds2 =
        FilterFactory.subtype(subtype -> subtype.endsWith("2"));
    DeckView filterViewEnd = object.filter(subtypeFilterEnds2);
    assertEquals("base1-1,base1-2,base1-4", filterViewEnd.toStringID());

    Predicate<JSONObject> subtypeFilterStartsStage =
        FilterFactory.subtype(subtype -> subtype.startsWith("Stage"));
    DeckView filterViewStart = object.filter(subtypeFilterStartsStage);
    assertEquals("base1-1,base1-2,base1-4", filterViewStart.toStringID());
  }

  @Test
  @DisplayName("test the combinations of filters")
  public void testFilterCombinations() {
    Predicate<JSONObject> subtypeFilterContainsB =
        FilterFactory.subtype(subtype -> subtype.contains("B"));
    DeckView filterViewContains = object.filter(subtypeFilterContainsB);
    assertEquals("base1-3,base1-5", filterViewContains.toStringID());

    Predicate<JSONObject> hpFilterBigger = FilterFactory.hp(hp -> hp > 100);
    DeckView filterViewBigger = object.filter(hpFilterBigger);
    assertEquals("base1-3,base1-4", filterViewBigger.toStringID());

    // Not
    DeckView filterViewNot = object.filter(FilterFactory.not(subtypeFilterContainsB));
    assertEquals("base1-1,base1-2,base1-4", filterViewNot.toStringID());

    // And
    DeckView filterViewAnd =
        object.filter(FilterFactory.and(subtypeFilterContainsB, hpFilterBigger));
    assertEquals("base1-3", filterViewAnd.toStringID());

    // Or
    DeckView filterViewOr = object.filter(FilterFactory.or(subtypeFilterContainsB, hpFilterBigger));
    assertEquals("base1-3,base1-4,base1-5", filterViewOr.toStringID());
  }

  @Test
  @DisplayName("test double filter type shit")
  public void testDoubleFilter() {
    Predicate<JSONObject> nameFilterBLength = FilterFactory.name(name -> name.length() > 7);
    DeckView filterViewBLength = object.filter(nameFilterBLength);
    assertEquals("base1-1,base1-2,base1-4,base1-5", filterViewBLength.toStringID());

    Predicate<JSONObject> hpFilterBigger = FilterFactory.hp(hp -> hp > 100);
    DeckView filterViewBigger = object.filter(hpFilterBigger);
    assertEquals("base1-3,base1-4", filterViewBigger.toStringID());

    // Double filter
    DeckView filterViewDouble = filterViewBLength.filter(hpFilterBigger);
    assertEquals("base1-4", filterViewDouble.toStringID());
  }
}
