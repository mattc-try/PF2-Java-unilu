# Laboratory "Hacking in Bash"

Nope, you won't really hack anything, but the name of this laboratory is cool.

## Answers to the laboratory

### Example of answer

This is an example to show you how to format your Bash code:

```sh
mkdir music
cd music
touch cool_stuff.txt
cd ..
```

### Question 1.2

Initially in ~ directory

```sh
mkdir BICS
cd BICS
mkdir PF2
cd ..
ls
cd ∼
pwd
/Users/shin
cd BICS/PF2/hacking_in_bash/BICS/PF2
```

* What does `ls` do ?
This command allows its user to show the files and folders in the current dirrectory that are visible won't show hidden files for this need -al for example.

* Where are you `pwd`?
`/Users/shin`
  What does ~ mean ?
This is the absolute path to the current user directory as you can see by the output of the `pwd`. I am now in the shin directory which is the current in use user on my laptop


### Question 1.3

```sh
cd
pwd
>/Users/shin
cd .
pwd
>/Users/shin
cd ..
pwd
>/Users
cd ../..
pwd
>/
cd /
pwd
>/
cd /home/
pwd
>/home
cd ~
pwd
>/Users/shin
cd ~/BICS/PF2
pwd
>/Users/shin/BICS/PF2
cd ~/BICS/../BICS/PF2
pwd
>/Users/shin/BICS/PF2
```

1, 5, 6, 7, 8 and 9 are absolute paths

2, 3, 4 are relative paths

The `/` path is the absolute path directing to the root of the current computer

The `.` changes directory to current directory it is thus relative.


### Question 1.4

```sh
ls *
ls .
ls ..
ls ../..
ls ~
ls /usr
ls /usr/*
ls /u*r/*
ls /u*/*
```

The star means "zero or more characters matching" and shows executable files in a directory, thus it will show files in sub directories. Alone `ls *` it will show all executable files. When used inside a path like on the line `ls /u*r/*` it means it will show every executable file in the directories that start with u and end with r. It's very usefull to find files with certain characters in the name or extensions.


### Question 1.7

```sh
wc -w music.txt
>   14 music.txt
grep -c e music.txt
>2
```


### Question 3

```sh
cd ~/BICS/PF2
mkdir test
touch file.txt
touch file2.txt
touch file3.txt
mv file.txt file2.txt file3.txt ..
cd ..
rm file.txt file2.txt file3.txt
```


### Question 4

If I want to make an important download on my computer but it may take multiple hours and I am going to sleep I can shutdown my computer when the download or operation is done

If for example the operation will take 5hr and 25 minutes, then:

```sh
sudo shutdown -h +360
```

I put 4 hours to make sure. If I suddently want to disable this timer.

```sh
sudo kill 434
```

If I want to restart my machine I can also do it from the terminal.

```sh
sudo shutdown -r now
```

