# Generics Laboratory
```mvn test``` for the testing, lazy to make test suite for exercise 1. There might be a way to test with ```mvn -Dtest=ListTest``` but I didn't find. If there is a better way pls inform me.

To run my implementation of the sorting ```mvn exec:java -Dexec.mainClass="ds.Generics"```

