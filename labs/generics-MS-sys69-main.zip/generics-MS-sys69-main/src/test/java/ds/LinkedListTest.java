package ds;

import static org.junit.jupiter.api.Assertions.*;

class LinkedListTest<T> extends ListTest<T> {
  @Override
  void whatInit() {
    list = new LinkedList<T>();
  }
}
