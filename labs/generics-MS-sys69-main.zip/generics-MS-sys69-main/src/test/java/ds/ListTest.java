package ds;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

abstract class ListTest<T> {
  protected List<T> list;

  abstract void whatInit();

  @BeforeEach
  void init() {
    whatInit();
  }

  void populate() {
    list.add((T) Integer.valueOf(4));
    list.add((T) Integer.valueOf(5));
    list.add((T) Integer.valueOf(6));
  }

  void testArrayContent(int size, String content) {
    assertEquals(content, list.toString());
    assertEquals(size, list.size());
    assertEquals(size == 0, list.isEmpty());
  }

  @Test
  @DisplayName("Clear elements in List")
  public void testClear() {
    testArrayContent(0, "");
    populate();
    list.clear();
    testArrayContent(0, "");
  }

  @Test
  @DisplayName("Search for an element in List")
  public void testIndexOf() {
    populate();
    assertEquals(1, list.indexOf((T) Integer.valueOf(5)));
    assertEquals(-1, list.indexOf((T) Integer.valueOf(10)));
    assertEquals(-1, list.indexOf(null));
  }

  @Test
  @DisplayName("Add elements in List")
  public void testAdd() {
    populate();
    testArrayContent(3, "4, 5, 6");
    list.add((T) Integer.valueOf(10), 2);
    testArrayContent(4, "4, 5, 10, 6");
  }

  @Test
  @DisplayName("Remove elements in List")
  public void testRemove() {
    populate();
    list.remove(1);
    testArrayContent(2, "4, 6");
    list.remove(1);
    testArrayContent(1, "4");
    assertThrows(ArrayIndexOutOfBoundsException.class, () -> list.remove(1));
    list.remove(0);
    testArrayContent(0, "");
  }

  @Test
  @DisplayName("Convert List to an Array")
  public void testToArray() {
    populate();
    Object[] array = list.toArray();
    assertArrayEquals(new Integer[] {4, 5, 6}, array);
    list.remove(0);
    list.remove(0);
    list.remove(0);
    array = list.toArray();
    assertArrayEquals(new Integer[] {}, array);
  }

  @Test
  @DisplayName("Add elements outside the list scope List")
  public void testAddOut() {
    populate();
    testArrayContent(3, "4, 5, 6");
    assertThrows(ArrayIndexOutOfBoundsException.class, () -> list.add((T) Integer.valueOf(10), 5));
  }
}
