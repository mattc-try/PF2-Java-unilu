package ds;

import static org.junit.jupiter.api.Assertions.*;

class DynamicArrayListTest<T> extends ListTest<T> {
  @Override
  void whatInit() {
    list = new DynamicArray<T>();
  }
}
