package ds;

public class Generics {
  public static void main(String[] args) {
    // My list of video games CSGO on top there is no toxicity and depression characteristic thank
    // god
    List<VideoGame> games = new LinkedList<VideoGame>();
    games.add(new VideoGame("Pokémon Legends: Arceus", 95, 80, 75, 10, 15, 90));
    games.add(new VideoGame("Counter Strike: Global Offensive", 0, 90, 100, 100, 100, 100));
    games.add(new VideoGame("Anno 1800", 100, 100, 100, 90, 5, 95));
    games.add(new VideoGame("Minecraft", 90, 100, 100, 5, 10, 100));

    // Sort the list of video games
    Algorithm.sort(games, true);
    System.out.println("Video games sorted by me on my pure Objectivity aha:");
    for (int i = 0; i < games.size(); i++) {
      System.out.println(games.get(i));
    }
    System.out.println();

    // Create a list of integers
    List<Integer> integers = new DynamicArray<Integer>();
    integers.add(5);
    integers.add(8);
    integers.add(2);
    integers.add(9);
    integers.add(7);
    integers.add(-7);
    integers.add(0);

    // Sort the list of integers in descending order like
    Algorithm.sort(integers, true);
    System.out.println("Sorted integers in descending order:");
    for (int i = 0; i < integers.size(); i++) {
      System.out.print(integers.get(i) + " ");
    }
    System.out.println();
  }
}
