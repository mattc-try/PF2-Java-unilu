package ds;

public class LinkedList<T> implements List<T> {
  private Node<T> sentinel;
  private Node<T> tail;
  private int size;

  @SuppressWarnings("unchecked")
  public LinkedList() {
    sentinel = new Node(0);
    size = 0;
    tail = sentinel;
  }

  /**
   * Check if the index is in bounds
   *
   * @param idx index to check
   */
  private void checkIndex(int idx) {
    if (idx < 0 || idx >= size) {
      throw new ArrayIndexOutOfBoundsException();
    }
  }

  /**
   * Return the value at the given index.
   *
   * @param idx index of the value to return
   * @return the value at the given index
   * @throws ArrayIndexOutOfBoundsException if the index is not in the range <code>0</code> to
   *     <code>size()-1</code>
   */
  @Override
  public T get(int idx) {
    checkIndex(idx);
    Node<T> n = sentinel.next;
    for (int i = 0; i < idx; i++) {
      n = n.next;
    }
    return n.value;
  }

  /**
   * Replace the value at the given index by the given value.
   *
   * @param idx index at which the value is to be replaced
   * @param element to store at the given index
   * @throws ArrayIndexOutOfBoundsException if the index is not in the range <code>0</code> to
   *     <code>size()-1</code>
   */
  @Override
  public void set(int idx, T element) {
    checkIndex(idx);
    Node<T> n = sentinel.next;
    for (int i = 0; i < idx; i++) {
      n = n.next;
    }
    n.value = element;
  }

  /**
   * Add a value at the end of the list.
   *
   * @param element to add at the end of the list
   */
  @Override
  public void add(T element) {
    Node<T> newNode = new Node<T>(element);
    // if (size == 0) {
    //   // set the head and tail to the newNode (1 element x)
    //   head = newNode;
    //   tail = newNode;
    // } else {
    // pudate the nextNode of the current tail to the newNode
    tail.next = newNode;
    // update the tail to the newNode
    tail = newNode;
    // }
    size++;
  }

  /**
   * Add a value at a specified index in the list
   *
   * @param element to add
   * @param idx index to add the value
   */
  @Override
  public void add(T element, int idx) {
    checkIndex(idx);
    // if (idx == 0) {
    //   // create a new node and make it the new head
    //   head = new Node(x, head);
    // } else {
    Node<T> n = sentinel.next;
    for (int i = 0; i < idx - 1; i++) {
      // get node before node at idx
      n = n.next;
    }
    // create a new node and insert it between the current node and the next node
    n.next = new Node<T>(element, n.next);
    if (idx == size) {
      // update the tail of the list
      tail = n.next;
    }
    // }
    size++;
  }

  /**
   * Remove a value at a specified index in the list
   *
   * @param idx index of the value to remove
   */
  @Override
  public void remove(int idx) {
    checkIndex(idx);
    // if (idx == 0) {
    //   // move the head to the next node in the list
    //   head = head.nextNode;
    // } else {
    Node<T> n = sentinel;
    for (int i = 0; i < idx; i++) {
      // get the node before node at idx
      n = n.next;
    }
    // remove the node by connecting the previous node to the next node
    n.next = n.next.next;
    if (idx == size - 1) {
      // update the tail
      tail = n;
    }
    // }
    size--;
  }

  /**
   * Find index of value in the list
   *
   * @param element in the list
   */
  @Override
  public int indexOf(T element) {
    Node<T> n = sentinel.next;
    for (int i = 0; i < size; i++) {
      if (n.value.equals(element)) {
        return i;
      }
      n = n.next;
    }
    return -1;
  }

  /** Check the if the list is empty */
  @Override
  public boolean isEmpty() {
    return size == 0;
  }

  /** Get the size */
  @Override
  public int size() {
    return size;
  }

  /** Clear the current list make it empty */
  @Override
  public void clear() {
    sentinel.next = null;
    tail = sentinel;
    size = 0;
  }

  /** Transform the linked list into a classic java array */
  @Override
  public T[] toArray() {
    T[] array = (T[]) new Object[size];
    Node<T> n = sentinel.next;
    int idx = 0;
    while (n != null) {
      array[idx] = n.value;
      n = n.next;
      idx += 1;
    }
    return array;
  }

  /** Transform the linked list into a readable output */
  @Override
  public String toString() {
    if (size == 0) {
      return "";
    }

    String str = "";
    Node<T> n = sentinel.next;
    str += n.value;
    n = n.next;

    while (n != null) {
      str += ", " + n.value;
      n = n.next;
    }

    return str;
  }

  private static class Node<T> {
    private T value;
    private Node<T> next;

    private Node(T x) {
      this(x, null);
    }

    private Node(T x, Node<T> next) {
      value = x;
      this.next = next;
    }
  }
}
