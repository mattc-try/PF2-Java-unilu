package ds;

public class Algorithm {
  /**
   * Selection Sort a list of comparable elements. The type of elements contained in the list must
   * thus be a class which implements the interface <code>Comparable</code>.
   *
   * @param <T> type of elements contained in the list
   * @param list given list to sort
   * @param ascending <code>true</code> if the list must be sorted in ascending order, <code>false
   *     </code> if it must be in descending order
   */
  public static <T extends Comparable<T>> void sort(List<T> list, boolean ascending) {
    int size = list.size();
    // Bubble sort first thought there was no particular algo to use
    // // go through each element in the list except the last one
    // for (int i = 0; i < size - 1; i++) {
    //   // iterate over each element except the sorted ones
    //   for (int j = 0; j < size - i - 1; j++) {
    //     // current element
    //     T x = list.get(j);
    //     // get the next element
    //     T y = list.get(j + 1);

    //     // compare the two elements using the compareTo method
    //     int z = x.compareTo(y);

    //     // if the order is incorrect, swap the two elements to make the order correct
    //     if ((ascending && z > 0) || (!ascending && z < 0)) {
    //       list.set(j, y);
    //       list.set(j + 1, x);
    //     }
    //   }
    // }

    // Loop through each element in the list except the last one
    for (int i = 0; i < size - 1; i++) {
      int min = i;

      for (int j = i + 1; j < size; j++) {
        if (ascending) {
          if (list.get(j).compareTo(list.get(min)) < 0) {
            min = j;
          }
        } else {
          if (list.get(j).compareTo(list.get(min)) > 0) {
            min = j;
          }
        }
      }

      T temp = list.get(min);
      list.set(min, list.get(i));
      list.set(i, temp);
    }
  }
}
