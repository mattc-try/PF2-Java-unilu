package ds;

public class DynamicArray<T> implements List<T> {
  private static int INITIAL_CAPACITY = 5;
  private T[] data;
  private int size;

  @SuppressWarnings("unchecked")
  public DynamicArray() {
    data = (T[]) new Object[INITIAL_CAPACITY];
    size = 0;
  }

  private void checkIndex(int idx) {
    if (idx < 0 || idx >= size) {
      throw new ArrayIndexOutOfBoundsException();
    }
  }

  /*
   * If the array `data` is full, then
   * 1. Create a new array `data2` doubling the size of `data`
   * 2. Copy the elements of `data` into `data2`
   * 3. Assign `data2` to `data`
   */

  private void realloc() {
    T[] data2 = (T[]) new Object[size * 2];
    for (int i = 0; i < size; i++) {
      data2[i] = data[i];
    }
    data = data2;
  }

  /**
   * Return the value at the given index.
   *
   * @param idx index of the value to return
   * @return the value at the given index
   * @throws ArrayIndexOutOfBoundsException if the index is not in the range <code>0</code> to
   *     <code>size()-1</code>
   */
  @Override
  public T get(int idx) {
    checkIndex(idx);

    return data[idx];
  }

  /**
   * Replace the value at the given index by the given value.
   *
   * @param idx index at which the value is to be replaced
   * @param element to store at the given index
   * @throws ArrayIndexOutOfBoundsException if the index is not in the range <code>0</code> to
   *     <code>size()-1</code>
   */
  @Override
  public void set(int idx, T element) {
    checkIndex(idx);

    data[idx] = element;
  }

  /**
   * Return the index of the first element equaling the given value.
   *
   * @param element to search for
   * @return the index of the first element equaling the given value, or -1 if no such element
   *     exists
   */
  @Override
  public int indexOf(T element) {
    if (element == null) {
      return -1;
    }
    for (int i = 0; i < size - 1; i++) {
      if (element.equals(data[i])) {
        return i;
      }
    }
    return -1;
  }

  /**
   * Add a value at the end of the array.
   *
   * @param element to add at the end of the array
   */
  @Override
  public void add(T element) {
    // T[] data2 = (T[]) new Object[size + 1];

    // for (int i = 0; i < size; i++) {
    //   data2[i] = data[i];
    // }

    // data2[data2.length - 1] = element;
    // data = data2;
    // size++;
    if (size == data.length) {
      realloc();
    }
    data[size++] = element;
  }

  /**
   * Add a value at given position in the array.
   *
   * @param element to add at the end of the array
   * @param idx position at which the value is to be added
   */
  @Override
  public void add(T element, int idx) {
    // T[] data2 = (T[]) new Object[size + 1];
    // for (int i = 0; i < size; i++) {
    //   if (!data[i].equals(0)) data2[i] = data[i];
    // }
    // data2[size] = data[idx];
    // data2[idx] = element;

    // data = data2;
    // size++;
    if (size == data.length) {
      realloc();
    }
    for (int i = size; i > idx; i--) {
      data[i] = data[i - 1];
    }
    data[idx] = element;
    size++;
  }

  /**
   * Remove the value at the given index.
   *
   * @param idx index of the value to be removed
   * @throws ArrayIndexOutOfBoundsException if the index is not in the range <code>0</code> to
   *     <code>size()-1</code>
   */
  @Override
  public void remove(int idx) {
    checkIndex(idx);
    for (int i = idx; i < size - 1; i++) {
      data[i] = data[i + 1];
    }
    size--;
  }

  /**
   * Return true if the array contains no value, false otherwise.
   *
   * @return true if the array contains no value, false otherwise
   */
  @Override
  public boolean isEmpty() {
    for (int i = 0; i < size; i++) {
      if (data[i] != null) {
        return false;
      }
    }
    return size == 0;
  }

  /**
   * Return the number of values in the array.
   *
   * @return the number of values in the array
   */
  @Override
  public int size() {
    return size;
  }

  /** Remove all of the values from the array. */
  @Override
  public void clear() {
    T[] empty = (T[]) new Object[0];
    data = empty;
    size = 0;
  }

  /**
   * Return a Java array containing all of the values in this array. This method must allocate a new
   * array. The caller is thus free to modify the returned array.
   *
   * @return a Java array containing all of the values in this array
   */
  @Override
  public T[] toArray() {
    T[] data2 = (T[]) new Object[size];
    for (int i = 0; i < size; i++) {
      data2[i] = data[i];
    }
    return data2;
  }

  /**
   * Create a string with the values of the array separated by comma, without a new line character
   * at the end. For instance: 4, 5, 6
   */
  @Override
  public String toString() {
    String output = "";
    for (int i = 0; i < size; i++) {
      output += data[i];

      if (i != size - 1) {
        output += ", ";
      }
    }
    return output;
  }
}
