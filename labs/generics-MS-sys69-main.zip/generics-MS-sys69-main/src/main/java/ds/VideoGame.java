package ds;

/** Implementation of a video game according to its rating based on different characteristics. */
public class VideoGame implements Comparable<VideoGame> {
  private String title;
  /*
   * The following members are characteristics on which is rated the video game.
   * Values should be integers between 0 and 100 included.
   */
  private int atmosphere;
  private int music;
  private int artisticDirection;
  private int graphism;
  private int scenario;
  private int gameplay;

  public VideoGame(
      String title,
      int atmosphere,
      int music,
      int artisticDirection,
      int graphism,
      int scenario,
      int gameplay) {
    checkIsPercentage(atmosphere);
    checkIsPercentage(music);
    checkIsPercentage(artisticDirection);
    checkIsPercentage(graphism);
    checkIsPercentage(scenario);
    checkIsPercentage(gameplay);
    this.title = title;
    this.atmosphere = atmosphere;
    this.music = music;
    this.artisticDirection = artisticDirection;
    this.graphism = graphism;
    this.scenario = scenario;
    this.gameplay = gameplay;
  }

  /*
   * Check if the given value is well between 0 and 100
   */
  private void checkIsPercentage(int x) {
    if (x < 0 || x > 100) {
      throw new NumberFormatException("The value should be between 0 and 100 included");
    }
  }

  @Override
  public String toString() {
    return title;
  }

  @Override
  public int compareTo(VideoGame other) {
    // Compare gameplay first (more important for me)
    int gameplayD = other.gameplay - this.gameplay;
    if (gameplayD != 0) {
      return gameplayD;
    }

    // If the gameplay is the same, compare next important characteristic
    // This way of comparing isn't great as a VideoGame might have mid gameplay and amazing for the
    // rest
    // and be superior to a video game with great gameplay but bad stats for the rest. Could do a
    // weighed average but
    // do I have time to waste probably not...
    int scenarD = other.scenario - this.scenario;
    if (scenarD != 0) {
      return scenarD;
    }

    int artisticD = other.artisticDirection - this.artisticDirection;
    if (artisticD != 0) {
      return artisticD;
    }

    int graphD = other.graphism - this.graphism;
    if (graphD != 0) {
      return graphD;
    }

    int musicD = other.music - this.music;
    if (musicD != 0) {
      return musicD;
    }

    int atmoD = other.atmosphere - this.atmosphere;
    if (atmoD != 0) {
      return atmoD;
    }

    // If all characteristics are the same, then the compared VideoGames must be equal hence return
    // 0
    return 0;
  }
}
