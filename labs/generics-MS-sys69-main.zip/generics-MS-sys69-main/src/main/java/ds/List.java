package ds;

/**
 * Abstract implementation of a list data structure.
 *
 * @param <T> type of elements in the list
 */
public interface List<T> {
  public T get(int idx);

  public void set(int idx, T element);

  public void add(T element);

  public void add(T element, int idx);

  public void remove(int idx);

  public int indexOf(T element);

  public boolean isEmpty();

  public int size();

  public void clear();

  public T[] toArray();

  @Override
  public String toString();
}
