package exploration;

public class Exploration {
  public static void main(String[] args) {
    Planet sku = new Planet(60, 90);
    Planet venus = new Planet(55, 10);
    Captain a = new Captain(55);
    Medic b = new Medic(77, 15, true);
    Medic c = new Medic(34, 67);
    Scientist d = new Scientist(90);
    Scientist e = new Scientist(90, false);

    System.out.println(a.isInterested(sku));
    System.out.println(b.isInterested(sku));
    System.out.println(c.isInterested(sku));
    System.out.println(d.isInterested(sku));
    System.out.println(e.isInterested(sku));
    Crew crew = new Crew(8);
    explore(crew, sku);
    explore(crew, venus);

    Crew crew2 = new Crew(199);
    explore(crew2, venus);
  }

  public static void explore(Crew crew, Planet planet) {
    if (crew.wantToExplorePlanet(planet)) {
      System.out.println("Let's explore " + planet + " ! with " + crew + ".");
    } else {
      System.out.println("Let's sleep with " + crew + " Zzz! " + planet + " sucks");
    }
  }
}
