package exploration;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class Crew {
  private int members;
  private ArrayList<CrewMember> crew;
  private int numInterested;

  public Crew(int members) {
    this.members = members;
    crew = new ArrayList<CrewMember>();
    for (int i = 0; i < members; i++) {
      crew.add(
          new Medic(
              ThreadLocalRandom.current().nextInt(100),
              ThreadLocalRandom.current().nextInt(100),
              ThreadLocalRandom.current().nextBoolean()));
    }
  }

  public boolean wantToExplorePlanet(Planet planet) {
    // Count the number of officers who are interested in exploring the planet
    int numInterestedOfficers = 0;
    int numOfficers = 0;
    for (int i = 0; i < members; i++) {
      if (crew.get(i).isInterested(planet) && crew.get(i).isOfficer) {
        numInterestedOfficers++;
      } else if (crew.get(i).isOfficer) {
        numOfficers++;
      }
    }

    // If a majority of the officers are interested, explore the planet
    if (numInterestedOfficers > numOfficers / 2) {
      return true;
    }

    // Count the total number of crew members who are interested
    int numInterested = 0;
    for (int i = 0; i < members; i++) {
      if (crew.get(i).isInterested(planet)) {
        numInterested++;
      }
    }

    // If more than two thirds of the crew are interested, explore the planet
    if (numInterested > (2 * members) / 3) {
      return true;
    }

    // Otherwise, do not explore the planet
    return false;
  }
}
