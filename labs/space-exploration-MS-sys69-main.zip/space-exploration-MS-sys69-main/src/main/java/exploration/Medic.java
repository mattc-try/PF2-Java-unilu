package exploration;

public class Medic extends CrewMember {

  public Medic(int dangerThreshold, int noveltyThreshold) {
    super(dangerThreshold, noveltyThreshold, false);
  }

  public Medic(int dangerThreshold, int noveltyThreshold, boolean isOfficer) {
    super(dangerThreshold, noveltyThreshold, isOfficer);
  }

  @Override
  public boolean isInterested(Planet planet) {
    if (planet.noveltyLevel() > noveltyThreshold && planet.dangerLevel() < dangerThreshold) {
      return true;
    }
    return false;
  }
}
