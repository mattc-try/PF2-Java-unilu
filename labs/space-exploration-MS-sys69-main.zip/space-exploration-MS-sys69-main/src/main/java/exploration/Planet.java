package exploration;

public class Planet {
  private int danger;
  private int novelty;

  public Planet(int danger, int novelty) {
    this.danger = danger;
    this.novelty = novelty;
  }

  public int dangerLevel() {
    return danger;
  }

  public int noveltyLevel() {
    return novelty;
  }
}
