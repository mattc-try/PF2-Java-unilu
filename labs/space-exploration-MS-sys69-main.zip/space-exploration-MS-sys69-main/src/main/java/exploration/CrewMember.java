package exploration;

public abstract class CrewMember {
  protected int dangerThreshold;

  protected int noveltyThreshold;
  protected boolean isOfficer;

  public CrewMember(int dangerThreshold, int noveltyThreshold, boolean isOfficer) {
    this.dangerThreshold = dangerThreshold;
    this.noveltyThreshold = noveltyThreshold;
    this.isOfficer = isOfficer;
  }

  public abstract boolean isInterested(Planet planet);

  // public abstract void voiceMail();
}
