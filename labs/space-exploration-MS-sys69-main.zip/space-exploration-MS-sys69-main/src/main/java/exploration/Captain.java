package exploration;

public class Captain extends CrewMember {

  public Captain(int dangerThreshold) {
    super(dangerThreshold, 0, true);
  }

  @Override
  public boolean isInterested(Planet planet) {
    if (planet.dangerLevel() > dangerThreshold) {
      return true;
    }
    return false;
  }
}
