package exploration;

public class Scientist extends CrewMember {

  public Scientist(int noveltyThreshold) {
    super(0, noveltyThreshold, false);
  }

  public Scientist(int noveltyThreshold, boolean isOfficer) {
    super(0, noveltyThreshold, isOfficer);
  }

  @Override
  public boolean isInterested(Planet planet) {
    if (planet.noveltyLevel() > noveltyThreshold) {
      return true;
    }
    return false;
  }
}
