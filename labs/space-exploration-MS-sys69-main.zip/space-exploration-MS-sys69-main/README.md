# Space Exploration Laboratory

The example given in the class is available in `src/main/java/phone/`.
To compile, run `mvn compile` and to execute the example, run `mvn exec:java -Dexec.mainClass="phone.Phoning" -q`.
