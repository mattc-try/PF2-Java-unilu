package ds;

/** Implementation of a sequential-access list data structure. */
public class LinkedList {
  private Node sentinel;
  private int size;
  private Node tail;

  public LinkedList() {
    sentinel = new Node(0);
    size = 0;
    tail = sentinel;
  }

  /**
   * Check if the index is in bounds
   *
   * @param idx index to check
   */
  private void checkIndex(int idx) {
    if (idx < 0 || idx >= size) {
      throw new ArrayIndexOutOfBoundsException();
    }
  }

  /**
   * Add a value at the end of the list.
   *
   * @param x value to add at the end of the list
   */
  public void add(int x) {
    Node newNode = new Node(x);
    // if (size == 0) {
    //   // set the head and tail to the newNode (1 element x)
    //   head = newNode;
    //   tail = newNode;
    // } else {
    // pudate the nextNode of the current tail to the newNode
    tail.nextNode = newNode;
    // update the tail to the newNode
    tail = newNode;
    // }
    size++;
  }

  /**
   * Add a value at a specified index in the list
   *
   * @param x value to add
   * @param idx index to add the value
   */
  public void add(int x, int idx) {
    checkIndex(idx);
    // if (idx == 0) {
    //   // create a new node and make it the new head
    //   head = new Node(x, head);
    // } else {
    Node n = sentinel.nextNode;
    for (int i = 0; i < idx - 1; i++) {
      // get node before node at idx
      n = n.nextNode;
    }
    // create a new node and insert it between the current node and the next node
    n.nextNode = new Node(x, n.nextNode);
    if (idx == size) {
      // update the tail of the list
      tail = n.nextNode;
    }
    // }
    size++;
  }

  /**
   * Remove a value at a specified index in the list
   *
   * @param idx index of the value to remove
   */
  public void remove(int idx) {
    checkIndex(idx);
    // if (idx == 0) {
    //   // move the head to the next node in the list
    //   head = head.nextNode;
    // } else {
    Node n = sentinel;
    for (int i = 0; i < idx; i++) {
      // get the node before node at idx
      n = n.nextNode;
    }
    // remove the node by connecting the previous node to the next node
    n.nextNode = n.nextNode.nextNode;
    if (idx == size - 1) {
      // update the tail
      tail = n;
    }
    // }
    size--;
  }

  /**
   * Find index of value in the list
   *
   * @param x value in the list
   */
  public int indexOf(int x) {
    Node n = sentinel.nextNode;
    for (int i = 0; i < size; i++) {
      if (n.value == x) {
        return i;
      }
      n = n.nextNode;
    }
    return -1;
  }

  /** Check the if the list is empty */
  public boolean isEmpty() {
    return size == 0;
  }

  /** Get the size */
  public int size() {
    return size;
  }

  /** Clear the current list make it empty */
  public void clear() {
    sentinel.nextNode = null;
    tail = sentinel;
    size = 0;
  }

  /** Transform the linked list into a classic java array */
  public int[] toArray() {
    int[] array = new int[size];
    Node n = sentinel.nextNode;
    int idx = 0;
    while (n != null) {
      array[idx] = n.value;
      n = n.nextNode;
      idx += 1;
    }
    return array;
  }

  /** Transform the linked list into a readable output */
  public String toString() {
    if (size == 0) {
      return "";
    }

    String str = "";
    Node n = sentinel.nextNode;
    str += n.value;
    n = n.nextNode;

    while (n != null) {
      str += ", " + n.value;
      n = n.nextNode;
    }

    return str;
  }

  /**
   * This is an "inner-class". A class inside a class. It is useful to keep `Node` private as it is
   * an implementation detail of linked list. By making `Node` an inner-class, we allow `LinkedList`
   * to access the private members of `Node`. Check the concept of inner class online for more
   * detail :-)
   */
  private static class Node {
    private int value;
    private Node nextNode;

    private Node(int x) {
      value = x;
      nextNode = null;
    }

    private Node(int x, Node next) {
      value = x;
      nextNode = next;
    }
  }
}
