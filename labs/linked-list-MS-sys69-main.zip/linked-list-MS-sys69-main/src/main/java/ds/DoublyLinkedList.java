package ds;

public class DoublyLinkedList {
  private Node head;
  private int size;

  public DoublyLinkedList() {
    head = null;
    size = 0;
  }

  /**
   * Check if the index is in bounds
   *
   * @param idx index to check
   */
  private void checkIndex(int idx) {
    if (idx < 0 || idx >= size) {
      throw new ArrayIndexOutOfBoundsException();
    }
  }

  /**
   * Add a value at the end of the list.
   *
   * @param x value to add at the end of the list
   */
  public void add(int x) {
    Node newNode = new Node(x);
    if (size == 0) {
      // set the head to the new node size 1
      head = newNode;
    } else {
      Node n = head;
      while (n.next != null) {
        // find the last node in the list
        n = n.next;
      }
      // set the newNode previous node to the last node
      newNode.prev = n;
      // set the last node next node to the newNode
      n.next = newNode;
    }
    size++;
  }

  /**
   * Add a value at a specified index in the list
   *
   * @param x value to add
   * @param idx index to add the value
   */
  public void add(int x, int idx) {
    checkIndex(idx);
    if (idx == 0) {
      // if adding at the head
      Node newNode = new Node(x, null, head);
      if (head != null) {
        head.prev = newNode;
      }
      // set the head to the newNode
      head = newNode;
    } else {
      Node n = head;
      for (int i = 0; i < idx - 1; i++) {
        // Find the node before node at idx
        n = n.next;
      }
      Node newNode = new Node(x, n, n.next);
      if (newNode.next != null) {
        // set the next node's previous node to the newNode
        newNode.next.prev = newNode;
      }
      // set the previous node's next node to the newNode
      n.next = newNode;
    }
    size++;
  }

  /**
   * Remove a value at a specified index in the list
   *
   * @param idx index of the value to remove
   */
  public void remove(int idx) {
    checkIndex(idx);
    if (idx == 0) {
      // set head to the next node
      head = head.next;
      if (head != null) {
        head.prev = null;
      }
    } else {
      Node n = head;
      for (int i = 0; i < idx - 1; i++) {
        // get to the node before the index
        n = n.next;
      }
      // set the previous node's next node to the next node
      n.next = n.next.next;
      if (n.next != null) {
        // set the next node's previous node to the previous node
        n.next.prev = n;
      }
    }
    size--;
  }

  /**
   * Find index of value in the list
   *
   * @param x value in the list
   */
  public int indexOf(int x) {
    Node n = head;
    for (int i = 0; i < size; i++) {
      if (n.value == x) {
        return i;
      }
      n = n.next;
    }
    return -1;
  }

  /** Check the if the list is empty */
  public boolean isEmpty() {
    return size == 0;
  }

  /** Get the size */
  public int size() {
    return size;
  }

  /** Clear the current list make it empty */
  public void clear() {
    size = 0;
    head = null;
  }

  /** Transform the linked list into a classic java array */
  public int[] toArray() {
    int[] array = new int[size];
    Node n = head;
    int idx = 0;
    while (n != null) {
      array[idx] = n.value;
      n = n.next;
      idx += 1;
    }
    return array;
  }

  /** Transform the linked list into a readable output */
  public String toString() {
    if (size == 0) {
      return "";
    }

    String str = "";
    Node n = head;
    str += n.value;
    n = n.next;

    while (n != null) {
      str += ", " + n.value;
      n = n.next;
    }

    return str;
  }

  private static class Node {
    private int value;
    private Node prev;
    private Node next;

    private Node(int x) {
      this(x, null, null);
    }

    private Node(int x, Node prev, Node next) {
      value = x;
      this.prev = prev;
      this.next = next;
    }
  }
}
