# Laboratory Linked List Data Structure

We program two implementations of linked lists, and try to understand their trade-offs in comparison to dynamic arrays!
