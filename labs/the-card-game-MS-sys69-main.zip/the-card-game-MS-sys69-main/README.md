# The Card Game

In this laboratory we implement a card game named "The Card Game".
The purpose is to get used to Java syntax and arrays.
To compile, run `mvn compile` and to execute the laboratory, run `mvn exec:java -Dexec.mainClass="cardgame.CardGame" -q`.