package cardgame;

import java.util.Scanner;

public class CardGame {
  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    System.out.println("Welcome to The Card Game!");

    Table t = new Table();
    int turn = 0;
    int move = 0;
    do {
      t.dealCards();
      // Note that ’toString’ is called automatically in a ’println’ so you can simply write:
      System.out.println(t);

      System.out.println("Your turn to play! Enter your moves like this: '[Card] [Pile]'.");

      do {
        System.out.print("Play your move! You can finish your turn by typing 'done': ");
        move = 0;
        move = askInput(s, t, move);
      } while (!s.nextLine().equals("done"));
      turn += 1;
      if (move < 2) break;

    } while (!t
        .win()); // logical issue creates infinite loop if or between conditions if move added here
    // To avoid infinite loop on victory i can't put the move in the while as it would return false
    // if at
    // the moment of winning the player does less than 2 moves
    if (t.win()) System.out.println("You win!");
    else if (move < 2) System.out.println("\nYou lose!");
  }


  /**
   * This function represents one turn of asking for parameters while the input isn't done and checking them
   * @param t The Table class where functions on the table are
   * @param m The number of moves while done isn't given as input
   * @return the number of moves made in one turn
   */
  public static int askInput(Scanner s, Table t, int m) {
    // System.out.print("Play your move! You can finish your turn by typing 'done': ");
    while (s.hasNextInt()) {
      int card = s.nextInt();
      int pile = s.nextInt();

      if ((pile < 1 || pile > 4)) {
        System.out.print("Play your move! You can finish your turn by typing 'done': ");

        continue;

        // System.out.print(
        // "Play a valid move '[Card] [Pile]'! You can finish the turn by typing 'done': ");
        // if (s.hasNextInt()) {
        //   card = s.nextInt();
        //   pile = s.nextInt();
        // }
      }

      if (t.playCard(pile - 1, card)) {
        m++;
      }

      System.out.print("Play your move! You can finish your turn by typing 'done': ");

      s.nextLine();
    }
    return m;
  }
}
