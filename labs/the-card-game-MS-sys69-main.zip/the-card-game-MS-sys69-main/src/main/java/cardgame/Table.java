package cardgame;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class Table {
  private int[] sizeOfStack;
  private ArrayList<Integer> hand;
  private ArrayList<Integer> drawPile;

  public Table() {
    sizeOfStack = new int[] {1, 1, 100, 100};
    hand = new ArrayList<Integer>();
    drawPile = new ArrayList<Integer>();
    for (int i = 2; i <= 99; i++) {
      drawPile.add(i);
    }
  }

  /**
   * This function creates strings and formats
   * according to what's asked in the lab at each turn
   */
  public String toString() {
    String output = "";
    output += "Draw Pile: " + drawPile.size() + " cards remaining.\n\n";

    for (int i = 0; i < sizeOfStack.length; i++) {
      output += "Stack " + (i + 1);
      if (i < 2) {
        output += "   (Up): " + sizeOfStack[i] + "\n";
      } else {
        output += " (Down): " + sizeOfStack[i] + "\n";
      }
    }
    output += "\nYour hand: ";

    for (int i = 0; i < hand.size(); i++) {
      output += hand.get(i);

      if (i != hand.size() - 1) {
        output += ", ";
      }
    }
    return output;
  }

  /**
   * This function plays a card on the Table
   * @param stackID the stack where the card should be added
   * @param card the card of the hand to be added on the table
   * @return a boolean representing if it was a valid move or nah
   */
  public boolean playCard(int stackID, int card) {
    if (!hand.contains(card)) {
      return false;
    }
    int idx = hand.indexOf(card);
    hand.remove(idx);
    int pile = stackID + 1;

    if (isValidMove(stackID, card)) {
      System.out.println("Placed " + card + " on pile " + pile + ".");
      sizeOfStack[stackID] = card;
      return true;
    }
    return false;
  }

  /**
   * This function checks if a card move is valid on it's pile
   * @param stackID the stack where we add the card
   * @param card the card to be checked
   * @return a boolean representing if the move is valid
   */
  private boolean isValidMove(int stackID, int card) {
    int pile = stackID + 1;

    if (sizeOfStack[stackID] - 10 == card || sizeOfStack[stackID] + 10 == card) {
      return true;
    }
    if (stackID == 0 || stackID == 1) {
      return sizeOfStack[stackID] < card;
    }
    if (stackID == 2 || stackID == 3) {
      return sizeOfStack[stackID] > card;
    }
    return false;
  }

  /**
   * This function deals cards to the player card at the beginning of each turn
   * while the number of cards in his hand is inferior to 8
   */
  public void dealCards() {
    while (hand.size() < 8) {
      int e = drawPile.size();
      // System.out.println(e);
      int pick = ThreadLocalRandom.current().nextInt(e);
      hand.add(drawPile.get(pick));
      drawPile.remove(pick);
      e -= 1;
    }
  }

  /**
   * This function checks if the use won the game
   * @return a boolean which is true if there is a win.
   */
  public boolean win() {
    if (hand.size() == 0 && drawPile.size() == 0) {
      return true;
    }
    return false;
  }
}
