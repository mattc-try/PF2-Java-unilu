# Laboratory Hash Table Data Structure

We program a hash table, which is a very useful data structure to model associative array (similarly to "dictionnary" `dict` in Python).
