package ds;

import java.util.ArrayList;
import java.util.List;

public class HashTable<K, V> {
  private static int INITIAL_CAPACITY = 8;
  private Entry<K, V>[] table;
  private int size;

  // Threshold for realloc
  private static final float THRESHOLD = 0.75f;

  @SuppressWarnings("unchecked")
  public HashTable() {
    table = (Entry<K, V>[]) new Entry[INITIAL_CAPACITY];
    size = 0;
  }

  private void checkKey(K key) {
    if (key == null) {
      throw new NullKeyException();
    }
  }

  /**
   * Hash function to map the keys to the values
   *
   * @param key the key associated to a value
   * @return the index of the value associated with the key
   */
  private int hashingFunction(K key) {
    int hash = key.hashCode();
    if (hash < 0) hash = -hash;
    return hash;
  }

  /*
   * Increases the size of the hash table and rehashes all entries.
   * The new size of the hash table will be double the current size.
   * This method is called internally when the load factor threshold is reached.
   */
  private void realloc() {
    Entry<K, V>[] table2 = (Entry<K, V>[]) new Entry[table.length * 2];

    for (int i = 0; i < table.length; i++) {
      Entry<K, V> entry = table[i];
      while (entry != null) {
        Entry<K, V> next = entry.next;
        // System.out.println(hashingFunction(entry.key));
        int index = hashingFunction(entry.key) % table2.length;

        entry.next = table2[index];
        table2[index] = entry;
        entry = next;
      }
    }

    table = table2;
  }

  /** Clears all key-value mappings from the hash table */
  public void clear() {
    size = 0;
    for (int i = 0; i < table.length; i++) {
      table[i] = null;
    }
  }

  /**
   * The size of the Hashtable
   *
   * @return the size of the hash table
   */
  public int size() {
    return size;
  }

  /**
   * Is the Hashtable empty
   *
   * @return a boolean signifying saying if there are values in the hash table
   */
  public boolean isEmpty() {
    return size == 0;
  }

  /**
   * Get value associated with key
   *
   * @param key the key associated to a value
   * @return the value associated to the key
   */
  public V get(K key) {
    checkKey(key);
    int idx = hashingFunction(key) % table.length;
    Entry<K, V> entry = table[idx];
    while (entry != null) {
      if (entry.key.equals(key)) {
        return entry.value;
      }
      entry = entry.next;
    }
    return null;
  }

  /**
   * Put or replace a key-value pair in the hashtable
   *
   * @param key the key associated to the value to put
   * @param value the value to put in the hashtable
   * @return the former value if the key was already in the table otherwise new pair is added and
   *     returns nul
   */
  public V put(K key, V value) {
    checkKey(key);
    int idx = hashingFunction(key) % table.length;
    Entry<K, V> entry = table[idx];
    while (entry != null) {
      if (entry.key.equals(key)) {
        V exValue = entry.value;
        entry.value = value;
        return exValue;
      }
      entry = entry.next;
    }
    Entry<K, V> entry2 = new Entry<>(key, value, table[idx]);
    table[idx] = entry2;
    size++;

    // When the threshold is reached double the capacity of the hash table
    if ((float) size / table.length >= THRESHOLD) {
      realloc();
    }

    return null;
  }

  /**
   * Remove a key value pair in the table from the key
   *
   * @param key the key associated to the pair to remove
   * @return the value associated to the key that is being removed or null if the key is not in the
   *     hashtable
   */
  public V remove(K key) {
    checkKey(key);
    int idx = hashingFunction(key) % table.length;
    Entry<K, V> prevVal = null;
    Entry<K, V> curVal = table[idx];
    while (curVal != null) {
      if (curVal.key.equals(key)) {
        if (prevVal == null) {
          table[idx] = curVal.next;
        } else {
          prevVal.next = curVal.next;
        }
        size--;
        return curVal.value;
      }
      prevVal = curVal;
      curVal = curVal.next;
    }
    return null;
  }

  /**
   * Transform the linked list into a readable output I chose to make my string similar to python
   * dictionnary syntax
   */
  @Override
  public String toString() {
    if (size == 0) {
      return "The HashTable is empty!";
    }

    String str = "{";
    boolean flag = true;

    for (Entry<K, V> entry : table) {
      while (entry != null) {
        if (!flag) {
          str += ", ";
        }
        str += "'" + entry.key + "' : '" + entry.value + "'";
        flag = false;
        entry = entry.next;
      }
    }
    str += "}";
    return str;
  }

  /**
   * Get a java List of all the keys in the Hashtable
   *
   * @return keyList all the keys in the Hashtable
   */
  public List<K> keys() {
    List<K> keyList = new ArrayList<>();
    for (int i = 0; i < table.length; i++) {
      Entry<K, V> entry = table[i];
      while (entry != null) {
        keyList.add(entry.key);
        entry = entry.next;
      }
    }
    return keyList;
  }

  /**
   * Check if the hashtable contains a certain key
   *
   * @param key the key associated to the pair to remove
   * @return a boolean that is true if the return of the get function isn't null basically that
   *     means there is a key
   */
  public boolean contains(K key) {
    return get(key) != null;
  }

  private static class Entry<K, V> {
    private K key;
    private V value;
    private Entry<K, V> next;

    public Entry(K key, V value) {
      this(key, value, null);
    }

    public Entry(K key, V value, Entry<K, V> next) {
      this.key = key;
      this.value = value;
      this.next = next;
    }
  }
}
