package ds;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class HashTableTest {
  private HashTable<String, Integer> table;

  @BeforeEach
  void init() {
    table = new HashTable<>();
  }

  private void populate() {
    table.put("key1", 1);
    table.put("key2", 7);
    table.put("key3", 0);
  }

  private void populate1000() {
    for (int i = 0; i < 1000; i++) {
      String key = "key" + i;
      table.put(key, i + 7);
    }
  }

  @Test
  @DisplayName("Test clear() and isEmpty()")
  void testClearEmptiness() {
    populate();
    table.clear();
    assertTrue(table.isEmpty());
    assertEquals(0, table.size());
    table.put("key1", 1);
    assertEquals(1, table.size());
  }

  @Test
  @DisplayName("Test size()")
  void testSize() {
    populate();
    assertEquals(3, table.size());
    table.put("key4", 11);
    assertEquals(4, table.size());
    table.put("key5", 12);
    table.put("key6", 13);
    table.put("key7", 14);
    table.put("key8", 15);
    table.put("key9", 16);
    table.put("key10", 17);
    assertEquals(10, table.size());
  }

  @Test
  @DisplayName("Test get()")
  void testGet() {
    assertNull(table.get("key1"));
    populate();
    assertEquals(1, table.get("key1"));
    table.put("key1", 2);
    assertEquals(2, table.get("key1"));
    assertEquals(7, table.get("key2"));
    assertNull(table.get("key4"));
  }

  @Test
  @DisplayName("Test remove()")
  void testRemove() {
    assertNull(table.remove("key1"));
    populate();
    assertEquals(1, table.remove("key1"));
    assertNull(table.get("key1"));
    assertEquals(7, table.remove("key2"));
    assertEquals(0, table.remove("key3"));
    assertTrue(table.isEmpty());
    assertNull(table.remove("key1"));
  }

  @Test
  @DisplayName("Test contains()")
  void testContains() {
    assertFalse(table.contains("key1"));
    populate();
    assertTrue(table.contains("key1"));
    assertTrue(table.contains("key2"));
    table.put("key2", 2);
    assertTrue(table.contains("key2"));
    table.remove("key1");
    assertFalse(table.contains("key1"));
    assertFalse(table.contains("key4"));
  }

  @Test
  @DisplayName("Test toString()")
  void testToString() {
    populate();
    String weWant = "{'key1' : '1', 'key2' : '7', 'key3' : '0'}";
    assertEquals(weWant, table.toString());
    table.put("key4", 11);
    weWant = "{'key1' : '1', 'key2' : '7', 'key3' : '0', 'key4' : '11'}";
    assertEquals(weWant, table.toString());
    table.remove("key3");
    weWant = "{'key1' : '1', 'key2' : '7', 'key4' : '11'}";
    assertEquals(weWant, table.toString());
  }

  @Test
  @DisplayName("Test keys()")
  void testKeys() {
    populate();
    assertEquals("[key1, key2, key3]", table.keys().toString());
    table.put("key4", 11);
    assertEquals("[key1, key2, key3, key4]", table.keys().toString());
  }

  @Test
  @DisplayName("Big Table")
  void bigTable() {
    populate1000();
    assertEquals(1000, table.size());
    for (int i = 0; i < 1000; i++) {
      assertEquals(i + 7, table.get("key" + i));
    }
  }
}
