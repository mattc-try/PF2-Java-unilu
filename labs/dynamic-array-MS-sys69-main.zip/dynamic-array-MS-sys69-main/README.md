# Laboratory Dynamic Array Data Structure

We program the standard `ArrayList` container of the Java Standard Library, yeay!
