package ds;

/** Class providing an algorithm for sorting a dynamic array and a binary search algorithm. */
public class Algorithm {
  /**
   * Process a selection sort on the given dynamic array.
   *
   * @param array dynamic array to sort
   */
  public static void sort(DynamicArray array) {
    for (int i = 0; i < array.size() - 1; i++) {
      int min = i;
      for (int j = i + 1; j < array.size(); j++) {
        if (array.get(j) < array.get(min)) min = j;
      }

      int temp = array.get(min);
      array.set(min, array.get(i));
      array.set(i, temp);
    }
  }

  /**
   * Process a binary search on the given dynamic array. The latter array is supposed to be already
   * sorted.
   *
   * @param array dynamic array in which the value is searched
   * @param x value to search
   * @return the index of the first occurrence of a matching value, and -1 if the array contains no
   *     such value
   */
  public static int search(DynamicArray array, int x) {
    int l = 0;
    int u = array.size() - 1;

    while (l <= u) {
      int mid = l + (u - 1) / 2;
      if (array.get(mid) == x) return mid;
      if (array.get(mid) == x) l = mid + 1;
      else u = mid - 1;
    }
    return -1;
  }
}
