package ds;

/** Implementation of a random-access resizable array. */
public class DynamicArray {
  private static int INITIAL_CAPACITY = 5;
  private int[] data;
  private int size;

  public DynamicArray() {
    data = new int[INITIAL_CAPACITY];
    size = 0;
  }

  private void checkIndex(int idx) {
    if (idx < 0 || idx >= size) {
      throw new ArrayIndexOutOfBoundsException();
    }
  }

  /*
   * If the array `data` is full, then
   * 1. Create a new array `data2` doubling the size of `data`
   * 2. Copy the elements of `data` into `data2`
   * 3. Assign `data2` to `data`
   */

  private void realloc() {
    int[] data2 = new int[size * 2];
    for (int i = 0; i < size - 1; i++) {
      data2[i] = data[i];
    }
    data = data2;
  }

  /**
   * Return the value at the given index.
   *
   * @param idx index of the value to return
   * @return the value at the given index
   * @throws ArrayIndexOutOfBoundsException if the index is not in the range <code>0</code> to
   *     <code>size()-1</code>
   */
  public int get(int idx) {
    checkIndex(idx);

    return data[idx];
  }

  /**
   * Replace the value at the given index by the given value.
   *
   * @param idx index at which the value is to be replaced
   * @param x value to store at the given index
   * @throws ArrayIndexOutOfBoundsException if the index is not in the range <code>0</code> to
   *     <code>size()-1</code>
   */
  public void set(int idx, int x) {
    checkIndex(idx);

    data[idx] = x;
  }

  /**
   * Return the index of the first element equaling the given value.
   *
   * @param x value to search for
   * @return the index of the first element equaling the given value, or -1 if no such element
   *     exists
   */
  public int indexOf(int x) {
    for (int i = 0; i < size - 1; i++) {
      if (x == data[i]) {
        return i;
      }
    }
    return -1;
  }

  /**
   * Add a value at the end of the array.
   *
   * @param x value to add at the end of the array
   */
  public void add(int x) {
    int[] data2 = new int[size + 1];

    for (int i = 0; i < size; i++) {
      data2[i] = data[i];
    }

    data2[data2.length - 1] = x;
    data = data2;
    size++;
  }

  /**
   * Add a value at given position in the array.
   *
   * @param x value to add at the end of the array
   * @param idx position at which the value is to be added
   */
  public void add(int x, int idx) {
    int[] data2 = new int[size + 1];
    for (int i = 0; i < size; i++) {
      if (data[i] != 0) data2[i] = data[i];
    }
    data2[size] = data[idx];
    data2[idx] = x;

    data = data2;
    size++;
  }

  /**
   * Remove the value at the given index.
   *
   * @param idx index of the value to be removed
   * @throws ArrayIndexOutOfBoundsException if the index is not in the range <code>0</code> to
   *     <code>size()-1</code>
   */
  public void remove(int idx) {
    checkIndex(idx);
    for (int i = idx; i < size - 1; i++) {
      data[i] = data[i + 1];
    }
    size--;
  }

  /**
   * Return true if the array contains no value, false otherwise.
   *
   * @return true if the array contains no value, false otherwise
   */
  public boolean isEmpty() {
    for (int i = 0; i < size - 1; i++) {
      if (data[i] != 0) {
        return false;
      }
    }
    return size == 0;
  }

  /**
   * Return the number of values in the array.
   *
   * @return the number of values in the array
   */
  public int size() {
    return size;
  }

  /** Remove all of the values from the array. */
  public void clear() {
    int[] empty = new int[0];
    data = empty;
    size = 0;
  }

  /**
   * Return a Java array containing all of the values in this array. This method must allocate a new
   * array. The caller is thus free to modify the returned array.
   *
   * @return a Java array containing all of the values in this array
   */
  public int[] toArray() {
    int[] data2 = new int[size];
    for (int i = 0; i < size - 1; i++) {
      data2[i] = data[i];
    }
    return data2;
  }

  /**
   * Create a string with the values of the array separated by comma, without a new line character
   * at the end. For instance: 4, 5, 6
   */
  public String toString() {
    String output = "";
    for (int i = 0; i < size; i++) {
      output += data[i];

      if (i != size - 1) {
        output += ", ";
      }
    }
    return output;
  }
}
