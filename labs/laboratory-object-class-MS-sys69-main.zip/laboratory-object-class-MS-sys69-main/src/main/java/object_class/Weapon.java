package object_class;

public abstract class Weapon {
  protected int damage;

  public Weapon(int damage) {
    this.damage = damage;
  }
}