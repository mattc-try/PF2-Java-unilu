package object_class;

public class Axe extends Weapon {
  private static final int DAMAGE = 10;
  public Axe() {
    super(DAMAGE);
  }
}