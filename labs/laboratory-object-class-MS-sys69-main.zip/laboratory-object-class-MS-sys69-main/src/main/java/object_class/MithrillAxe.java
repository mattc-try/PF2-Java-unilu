package object_class;

public class MithrillAxe extends Axe {
  private boolean madeByDwarf;

  public MithrillAxe(boolean madeByDwarf) {
    this.madeByDwarf = madeByDwarf;
  }
}
