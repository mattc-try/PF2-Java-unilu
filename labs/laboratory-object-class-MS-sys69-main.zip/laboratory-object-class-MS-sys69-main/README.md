# Programming fundamentals 2 - Object class laboratory

This is the companion code and exercises of the lecture _(Almost) Everything is Object_.
