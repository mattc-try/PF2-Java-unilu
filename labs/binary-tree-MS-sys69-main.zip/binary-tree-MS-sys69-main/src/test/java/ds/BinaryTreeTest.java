package ds;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class BinarySearchTreeTest {
  BinarySearchTree<Integer, String> table;
  BinarySearchTree<Integer, Integer> integerTree;

  @BeforeEach
  void init() {
    table = new BinarySearchTree<>();
    // Just to show it works with dif data types
    integerTree = new BinarySearchTree<>();
  }

  private void pokemonPopulate() {
    table.put(7, "Squirtle");
    table.put(1, "Bulbasaur");
    table.put(44, "Gloom");
    table.put(31, "Nidoqueen");
    table.put(123, "Scyther");
    table.put(37, "Vulpix");
    table.put(94, "Gengar");
    table.put(141, "Kabutops");
  }

  @Test
  @DisplayName("Very basic put() and get() method tests")
  void testBasicMethods() {
    assertNull(table.put(1, "so"));
    assertNull(table.put(7, "much"));
    assertNull(table.put(2, "fun"));
    assertEquals("so", table.get(1));
    assertEquals("fun", table.get(2));
    assertEquals("much", table.get(7));
  }

  @Test
  @DisplayName("put() updating case")
  void testUpdatePut() {
    assertNull(table.put(1, "yes"));
    assertEquals("yes", table.put(1, "no"));
    assertEquals("no", table.get(1));
  }

  @Test
  @DisplayName("Testing the size of the Tree")
  void testSize() {
    assertEquals(0, table.size());
    table.put(1, "one");
    assertEquals(1, table.size());
    table.put(2, "two");
    assertEquals(2, table.size());
    table.remove(1);
    assertEquals(1, table.size());
    table.remove(2);
    assertEquals(0, table.size());
  }

  @Test
  @DisplayName("remove() method")
  void testRemove() {
    assertNull(table.put(1, "so"));
    assertNull(table.put(7, "much"));
    assertNull(table.put(2, "fun"));
    assertEquals("so", table.remove(1));
    assertNull(table.get(1));
    assertNull(table.remove(77));
    assertEquals(2, table.size());
  }

  @Test
  @DisplayName("Testing the isEmpty() method on tree")
  void testEmptyTree() {
    assertNull(table.get(1));
    assertNull(table.remove(1));
    assertFalse(table.contains(1));
    assertEquals(0, table.size());
    assertTrue(table.isEmpty());
  }

  @Test
  @DisplayName("Testing the clear() method on tree")
  void testClear() {
    assertNull(table.put(1, "so"));
    assertNull(table.put(7, "much"));
    assertNull(table.put(2, "fun"));
    table.clear();
    assertTrue(table.isEmpty());
    assertEquals(0, table.size());
    assertNull(table.get(1));
    assertNull(table.get(7));
    assertNull(table.get(2));
  }

  @Test
  @DisplayName("Testing the contains() method on tree")
  void testContains() {
    assertNull(table.put(1, "yes"));
    assertTrue(table.contains(1));
    assertFalse(table.contains(77));
  }

  @Test
  @DisplayName("Doing some fun tests on a larger tree, failed last lab cos of that soo")
  void testLargeTree() {
    int n = 1000;

    // insert n elements
    for (int i = 1; i <= n; i++) {
      assertNull(table.put(i, "value" + i));
    }

    // check that all elements are present
    for (int i = 1; i <= n; i++) {
      assertEquals("value" + i, table.get(i));
    }

    // remove all odd elements
    for (int i = 1; i <= n; i += 2) {
      assertNotNull(table.remove(i));
    }

    // check that only even elements are present
    for (int i = 2; i <= n; i += 2) {
      assertEquals("value" + i, table.get(i));
      assertFalse(table.contains(i - 1));
    }

    // remove all even elements
    for (int i = 2; i <= n; i += 2) {
      assertNotNull(table.remove(i));
    }

    // check that the tree is now empty
    assertNull(table.get(1));
    assertEquals(0, table.size());
    assertTrue(table.isEmpty());
  }

  @Test
  @DisplayName("Testing for an integer tree")
  void testIntegerTree() {
    assertNull(integerTree.put(1, 2));
    assertNull(integerTree.put(7, 3));
    assertNull(integerTree.put(2, 4));
    assertEquals(2, integerTree.remove(1));
    assertNull(integerTree.get(1));
    assertNull(integerTree.remove(4));
    assertEquals(2, integerTree.size());
  }

  @Test
  @DisplayName("Testing of the toString() method")
  void testToString() {
    assertEquals("", table.toString());
    pokemonPopulate();
    String expected =
        "7:Squirtle\n"
            + "|_1:Bulbasaur\n"
            + "   |_null\n"
            + "   |_null\n"
            + "|_44:Gloom\n"
            + "   |_31:Nidoqueen\n"
            + "      |_null\n"
            + "      |_37:Vulpix\n"
            + "         |_null\n"
            + "         |_null\n"
            + "   |_123:Scyther\n"
            + "      |_94:Gengar\n"
            + "         |_null\n"
            + "         |_null\n"
            + "      |_141:Kabutops\n"
            + "         |_null\n"
            + "         |_null\n";

    assertEquals(expected, table.toString());
  }

  @Test
  @DisplayName("Testing of the keys() method")
  void testKeys() {
    List<Integer> keys = table.keys();
    assertEquals("[]", keys.toString());
    assertTrue(keys.isEmpty());
    pokemonPopulate();
    keys = table.keys();
    String expected = "[7, 1, 44, 31, 123, 37, 94, 141]";
    assertEquals(expected, keys.toString());
  }
}
