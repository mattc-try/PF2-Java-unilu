package ds;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

public class BinarySearchTree<K extends Comparable<K>, V> {
  private Node<K, V> root;
  private int size;

  public BinarySearchTree() {
    root = null;
    size = 0;
  }

  private void checkKey(K key) {
    if (key == null) {
      throw new NullKeyException();
    }
  }

  /** Clear the root of the tree destroying my boy the tree */
  public void clear() {
    root = null;
    size = 0;
  }

  /**
   * The size of the Binary Tree
   *
   * @return the size of the BinarySearchTree
   */
  public int size() {
    return size;
  }

  /**
   * Is the BinarySearchTree empty
   *
   * @return a boolean signifying if there are values in the Tree or nah
   */
  public boolean isEmpty() {
    return size == 0;
  }

  /**
   * Returns the value associated with the given key in the binary search tree if it is found
   *
   * @param key the key to search for
   * @throws NullPointerException if the given key is null
   * @return the value associated with the key, or null if the key isn't found
   */
  public V get(K key) {
    checkKey(key);
    // Start searching from the root node
    Node<K, V> node = root;
    // Go through the tree until either the key is found or no more nodes
    while (node != null) {
      // Compare the key with the key of the current node
      int whoBigger = key.compareTo(node.key);
      // Smaller, go left
      if (whoBigger < 0) {
        node = node.childLeft;
        // Bigger, go right
      } else if (whoBigger > 0) {
        node = node.childRight;
        // Equals, return the value associated with the key
      } else {
        return node.value;
      }
    }
    // Not found
    return null;
  }

  /**
   * Inserts the specified key-value mapping into this Tree if it isn't already there. When the key
   * already exists, the associated value will be modified to the new one and the former value will
   * be returned.
   *
   * @param key the key to be inserted
   * @param value the value to be mapped with the key with the key
   * @throws NullPointerException if the specified key is null
   * @return the former value associated with the key, or null if it's a new key
   */
  public V put(K key, V value) {
    checkKey(key);
    // Empty tree, create a new root node yessir
    if (root == null) {
      root = new Node<>(key, value, null);
      size++;
      return null;
    }

    // Not empty, start searching from the root node
    Node<K, V> node = root;
    // Go through the tree until either the key is found or no more nodes
    while (true) {
      // Compare the key with the key of the current node
      int whoBigger = key.compareTo(node.key);

      // Smaller go left
      if (whoBigger < 0) {
        // If there isn't a node it's empty create it and return null
        if (node.childLeft == null) {
          node.childLeft = new Node<>(key, value, node);
          size++;
          return null;
          // Else update the node and continue searching
        } else {
          node = node.childLeft;
        }

        // Bigger, go right
      } else if (whoBigger > 0) {
        // If there isn't a node it's empty create it and return null
        if (node.childRight == null) {
          node.childRight = new Node<>(key, value, node);
          size++;
          return null;
          // Else update the node and continue searching
        } else {
          node = node.childRight;
        }

        // The key was found update the value, and return former
      } else {
        V formerValue = node.value;
        node.value = value;
        return formerValue;
      }
    }
  }

  /**
   * Removes the node with the given key from the Tree. If key is not found in then returns
   * null(nothing isdone).
   *
   * @param key the key of the node to remove
   * @return the value associated with the removed node, or null if the key is not found
   */
  public V remove(K key) {
    Node<K, V> node = root;
    Node<K, V> parent = null;

    // Go through the tree until either the key is found or no more nodes
    while (node != null) {
      int whoBigger = key.compareTo(node.key);
      if (whoBigger == 0) {
        break;
      } else if (whoBigger < 0) {
        parent = node;
        node = node.childLeft;
      } else {
        parent = node;
        node = node.childRight;
      }
    }

    // node is not found, return null
    if (node == null) {
      return null;
    }

    // Store the value of the node we want to remove
    V formerValue = node.value;

    // If the node has two children, replace it with its successor
    if (node.childLeft != null && node.childRight != null) {
      Node<K, V> successor = node.childRight;
      while (successor.childLeft != null) {
        successor = successor.childLeft;
      }
      node.key = successor.key;
      node.value = successor.value;
      node = successor;
    }

    // Determine the replacement node, first check the left child if it's null try right child if
    // both are null
    // It's a leaf node and replacement is null
    Node<K, V> replacement = (node.childLeft != null ? node.childLeft : node.childRight);

    // Update the parent of the replacement node
    if (replacement != null) {
      replacement.parent = node.parent;
    }

    // Update the parent of the node to remove
    if (node.parent == null) {
      root = replacement;
    } else if (node == node.parent.childLeft) {
      node.parent.childLeft = replacement;
    } else {
      node.parent.childRight = replacement;
    }

    size--;
    return formerValue;
  }

  /**
   * Returns true if the tree contains a node with the given key, false otherwise.
   *
   * @param key the key of the given node to search for
   * @return true if the node is found false otherwise
   */
  public boolean contains(K key) {
    // In case the key is null immediatelly return false can't be foound
    if (key == null) {
      return false;
    }
    // Start searching from the root node
    Node<K, V> node = root;
    while (node != null) {
      // Compare the key with the key of the current node
      int whoBigger = key.compareTo(node.key);
      // Smaller go left
      if (whoBigger < 0) {
        node = node.childLeft;
        // Bigger, go right
      } else if (whoBigger > 0) {
        node = node.childRight;
        // found the node (equals)
      } else {
        return true;
      }
    }
    // node not found
    return false;
  }

  /**
   * Create a string with the values of the BinaryTree shown with a kind off Tree representation
   * through depth-first search (DFS)
   *
   * @return a string containing a representation of the BinarySearchTree
   */
  @Override
  public String toString() {
    if (root == null) {
      return "";
    }

    String output = "";
    ArrayDeque<Node<K, V>> stack = new ArrayDeque<>();
    ArrayDeque<String> prefixes = new ArrayDeque<>();
    stack.addFirst(root);
    prefixes.addFirst("");

    while (!stack.isEmpty()) {
      Node<K, V> node = stack.removeFirst();
      String prefix = prefixes.removeFirst();

      output += prefix + "|" + node.key + ":" + node.value + "\n";

      if (node.childRight != null) {
        stack.addFirst(node.childRight);
        prefixes.addFirst(prefix + "   ");
      } else {
        output += prefix + "   |_" + " null\n";
      }

      if (node.childLeft != null) {
        stack.addFirst(node.childLeft);
        prefixes.addFirst(prefix + "|_ ");
      } else {
        output += prefix + "|_ " + " null\n";
      }
    }

    return output.trim();
  }

  public List<K> keys() {
    List<K> result = new ArrayList<>();
    if (root == null) {
      return result;
    }

    Queue<Node<K, V>> queue = new ArrayDeque<>();
    queue.add(root);

    while (!queue.isEmpty()) {
      Node<K, V> node = queue.poll();
      result.add(node.key);

      if (node.childLeft != null) {
        queue.add(node.childLeft);
      }
      if (node.childRight != null) {
        queue.add(node.childRight);
      }
    }

    return result;
  }

  private static class Node<K extends Comparable<K>, V> {
    private K key;
    private V value;
    private Node<K, V> parent;
    private Node<K, V> childLeft;
    private Node<K, V> childRight;

    private Node(K key, V value, Node<K, V> parent) {
      this(key, value, parent, null, null);
    }

    private Node(K key, V value, Node<K, V> parent, Node<K, V> childLeft, Node<K, V> childRight) {
      this.key = key;
      this.value = value;
      this.parent = parent;
      this.childLeft = childLeft;
      this.childRight = childRight;
    }
  }
}
