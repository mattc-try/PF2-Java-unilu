# Laboratory Binary Tree Data Structure

We program a binary tree, which is, like Hash Table, can be used to model associative array (similarly to "dictionnary" `dict` in Python).

```mvn test```