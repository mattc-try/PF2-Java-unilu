package hello_world;
import java.util.Scanner;
import hello_world.ArrayComputing;
public class ScientificComputing {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.print("How many numbers do you get today? ");
    int size = scanner.nextInt();
    while (size<=0) {
      size = scanner.nextInt();
    }

    ArrayComputing a = new ArrayComputing(size);
    System.out.println(a);
    System.out.print("Please enter an array of "+ size + " numbers: ");
    a.readArray(scanner);
    a.print();
    System.out.println(a.min());
    System.out.println(a.max());
    ArrayComputing accumulated = a.accumulate();
    accumulated.print();
    System.out.println(accumulated.min());
    System.out.println(accumulated.max());
    a.print();


  }


}

