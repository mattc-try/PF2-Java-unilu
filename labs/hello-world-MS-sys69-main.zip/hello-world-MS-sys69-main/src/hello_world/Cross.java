package hello_world;
class Cross {
  private int height;
  private int width;
  private int inter;



  public Cross(int h, int w, int i) {
    height = h;
    width = w;
    inter = i;
  }

  public void draw() {
    for(int i = 0; i < height; ++i) {
      for(int j = 0; j < width; ++j) {
        if((j == width /2 ) || (i == height - inter)) {
          System.out.print("*");
        } else if (j <width/2) {
          System.out.print(" ");
        }
      }
      System.out.println("");
    }
  }
}
