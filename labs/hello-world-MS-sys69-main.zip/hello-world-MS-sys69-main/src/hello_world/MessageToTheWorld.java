package hello_world;

class MessageToTheWorld {

  public static void main(String[] args) {
    System.out.println("My name is Phileas Fogg, and I’m gonna be a coding legend.");
  }
}