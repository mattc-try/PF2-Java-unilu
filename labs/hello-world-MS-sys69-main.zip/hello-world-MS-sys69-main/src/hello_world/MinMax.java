package hello_world;
import java.util.Scanner;
public class MinMax {
  public static void main(String[] args) {
    // Add Scanner
    Scanner scanner = new Scanner(System.in);
    // Ask for the two integers
    System.out.print("Type two integers: ");
    // Record the two next integer inputs on the same line
    int a = scanner.nextInt();
    int b = scanner.nextInt();
    // Print the minimum on the next line
    System.out.println(min(a, b));
    // Print the maximum on the next line
    System.out.println(max(a, b));

    System.out.print("How many numbers do you want to type? ");
    // Here, we expect the user to write an integer (if they write something else, it will explode to your face with an exception.)
    int n = scanner.nextInt();
    while (n<=0) {
      System.out.print("Try again: ");
      n = scanner.nextInt();
    }
    if (n > 0) {
      // We create an array of n elements.
      int[] numbers = new int[n];
      // Ask for n numbers and compare them to get max and min.
      arrayMinMax(scanner, numbers);
    }


    // Ask for numbers
    System.out.println("Type a sequence of numbers (end the sequence with -1):");
    // Keeps asking for numbers unless the number is -1 and compares the numbers to get max and min.
    sequenceMinMax(scanner);
  }
  public static int min(int a, int b) {
    if (b <= a) {
      return b;
    }
    else {
      return a;
    }
  }
  public static int max(int a, int b) {
    if (a >= b) {
      return a;
    }
    else {
      return b;
    }
  }
  static void arrayMinMax(Scanner scanner, int[] numbers) {
    // initialise the first element of the numbers array
    numbers[0] = scanner.nextInt();
    // This number is not compared it will be the first max and min
    int max = numbers[0];
    int min = numbers[0];
    // Loop through the array length
    for(int i = 1; i < numbers.length; ++i) {
      // Ask for each element in the array
      numbers[i] = scanner.nextInt();
      // Compare the last max or min to the new element in the array
      max = max(max, numbers[i]);
      min = min(min, numbers[i]);

    }
    // print out max and min
    System.out.println(min);
    System.out.println(max);
  }
  static void sequenceMinMax(Scanner scanner) {
    // Ask for the initial sequence input
    int input = scanner.nextInt();
    // Initialise the max and min to that input
    int max = input;
    int min = input;
    // Keep asking for the next number if the input isn't -1
    while (input != -1) {
      // ask for the input
      input = scanner.nextInt();
      // if the input isn't -1 which ends the sequence
      if (input != -1) {
        // Compare the last max or min to the most recent input
        max = max(max, input);
        min = min(min, input);
      }
    }
    // print out max and min
    System.out.println(min);
    System.out.println(max);
  }
}

