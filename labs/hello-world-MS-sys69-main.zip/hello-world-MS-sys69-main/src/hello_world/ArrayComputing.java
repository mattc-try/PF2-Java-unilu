package hello_world;
import java.util.Scanner;
public class ArrayComputing {
  private int[] array;
  private int[] data;

  public ArrayComputing(int size) {
    array = new int[size];
    data = new int[size];
  }
  public void readArray(Scanner scanner) {
    for (int i=0; i<array.length; ++i) {
      array[i] = scanner.nextInt();
    }

  }
  public void print() {

    for (int i=0; i<array.length; ++i) {
      System.out.print(array[i] + " ");
    }
    System.out.println();
  }
  public int min() {
    int min = array[0];
    for (int i = 1; i < array.length; i++) {
      if (min > array[i]) {
        min = array[i];
      }
    }
    return min;
  }

  public int max() {
    int max = array[0];
    for (int i = 1; i < array.length; i++) {
      if (max < array[i]) {
        max = array[i];
      }
    }
    return max;



  }
  public ArrayComputing accumulate() {
    ArrayComputing accumulatedArray = new ArrayComputing(array.length);
    for (int i = 0; i < array.length; i++) {
         accumulatedArray.array[i] = array[i];
      }
    int sum = accumulatedArray.array[0];
    for (int i = 1;i < array.length; ++i) {

      accumulatedArray.array[i] = sum + array[i];
      sum += array[i];
    }
    return accumulatedArray;
  }


}