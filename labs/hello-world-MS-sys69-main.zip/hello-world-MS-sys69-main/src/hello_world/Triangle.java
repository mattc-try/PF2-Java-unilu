package hello_world;
class Triangle {
  private int base;



  public Triangle(int b) {
    base = b;
  }
  public void draw() {
    for(int i = 0; i < base; ++i) {
      for(int j = 0; j < i+1; ++j) {
        System.out.print("*");
      }
      System.out.println("");
    }
  }
}