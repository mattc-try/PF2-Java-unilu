package hello_world;
import java.util.Scanner;
import hello_world.Rectangle;
import hello_world.Triangle;
public class AdvancedGeometry {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    // Rectangle r1 = new Rectangle(3, 5);
    // Rectangle r2 = new Rectangle(10, 50);
    // // Ask the objects to print themselves.
    // r1.draw();
    // r2.draw();
    // Add Scanner
    System.out.println("Please select what shapes we can draw for you: ");
    System.out.println("1. Rectangle");
    System.out.println("2. Triangle");
    System.out.println("3. Cross");
    System.out.print("Please enter your choice: ");
    int choice = scanner.nextInt();
    while (choice != 1 && choice != 2 && choice != 3) {
      choice = scanner.nextInt();
    }

    if (choice == 1) {
      // Ask for height
      System.out.print("Enter the height of the rectangle: ");
      int height = scanner.nextInt();
      while (height <= 0) {
        height = scanner.nextInt();
      }
      System.out.print("Enter the width of the rectangle: ");
      // Record the two next integer inputs on the same line
      int width = scanner.nextInt();
      while (width <= 0) {
        width = scanner.nextInt();
      }
      Rectangle r = new Rectangle(height, width);
      r.draw();

    } else if (choice == 2) {
      // Ask for height
      System.out.print("Enter the base of your triangle: ");
      int base = scanner.nextInt();
      while (base <= 0) {
        base = scanner.nextInt();
      }
      Triangle t = new Triangle(base);
      t.draw();

    } else if (choice == 3) {
      // Ask for height
      System.out.print("Enter the height of your cross: ");
      int height = scanner.nextInt();
      while (height <= 0) {
        height = scanner.nextInt();
      }
      System.out.print("Enter the width of your cross: ");
      // Record the two next integer inputs on the same line
      int width = scanner.nextInt();
      while (width <= 0) {
        width = scanner.nextInt();
      }
      while (width % 2 == 0) {
        System.out.println("Error: the width must be an odd number! ");
        System.out.print("Enter the width of your cross: ");
        width = scanner.nextInt();

      }
      System.out.print("Enter the intersection height: ");
      int inter = scanner.nextInt();
      while (inter <= 0) {
        inter = scanner.nextInt();
      }
      Cross c = new Cross(height, width, inter);
      c.draw();
    }
    // // Ask for height
    // System.out.print("Enter the height of the rectangle: ");
    // int height = scanner.nextInt();
    // System.out.print("Enter the width of the rectangle: ");
    // // Record the two next integer inputs on the same line
    // int width = scanner.nextInt();
    // Rectangle r = new Rectangle(height, width);
    // r.draw();


  }

}

