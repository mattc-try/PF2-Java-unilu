# Hello World laboratory

Learn the basics of Java (imperative kernel).

To compile the demo file, run `javac -d target src/hello_world/HelloWorld.java` from the root folder of this project.
Then to execute the program, run `java -cp target hello_world.HelloWorld`.
